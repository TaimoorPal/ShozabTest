package galaxyProjectObjects;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class objects {
	
	
	WebDriver driver;

	
	
	 @FindBy(xpath="//a[contains(text(),'Printer & Scanner')]")
	//ul[@class='dropdown-menu yamm']//child::a[contains(text(),'Printer & Scanner')]
	 public List<WebElement> PrinterScanner ;
	 
	 
	 @FindBy(xpath="//ul[@class='dropdown-menu yamm']//child::a[contains(text(),'Printer & Scanner')]//following-sibling::ul[@class=' dropdown-menu']//child::strong")
	 public List<WebElement> header ; 
	 
	 
	 @FindBy(xpath="//ul[@class='dropdown-menu yamm']//child::a[contains(text(),'Printer & Scanner')]//following-sibling::ul[@class=\" dropdown-menu\"]//child::strong[text()='Printers']//parent::li//following-sibling::li//child::a")
	 public List<WebElement> printerList ; 
	 
	 @FindBy(xpath="//ul[@class='dropdown-menu yamm']//child::a[contains(text(),'Printer & Scanner')]//following-sibling::ul[@class=\" dropdown-menu\"]//child::strong[text()='Toner & Cartridges']//parent::li//following-sibling::li//child::a")
	 public List<WebElement> tonerList ;
	
	 @FindBy(xpath="//ul[@class='dropdown-menu yamm']//child::a[contains(text(),'Printer & Scanner')]//following-sibling::ul[@class=' dropdown-menu']//child::strong[text()='Printers']//parent::li//following-sibling::li//child::a[text()='HP']")
	 public WebElement hpButton ;
	 
	 
	
	
	
	
	public objects(WebDriver driver){

        this.driver = driver;

        //This initElements method will create all WebElements

        PageFactory.initElements(driver, this);
 }

}
