package galaxyProjectTests;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import galaxyProjectObjects.baseClass;
import galaxyProjectObjects.objects;
import galaxyProjectObjects.utility;

public class testCases {
	
	
	WebDriver driver;
	baseClass basepage;
	utility Utility;
	objects obj;
	Actions actions;
	
  @BeforeTest
  public void setUp() {
	  
	  basepage = new baseClass();
	  driver = basepage.initialize_driver();
	  Utility = new utility("C:\\Users\\shozab.iftikhar\\eclipse-workspace\\galaxyProject\\Book2.xlsx");
	  obj = new objects(driver);
	  
  }
  
  @Test
  public void test() {
	  
	  //Open url
	  driver.get("https://galaxy.pk/");
	  
	  WebElement element = obj.PrinterScanner.get(1);
	  

	  actions = new Actions(driver);
	  actions.moveToElement(element).perform();
	  
	  int i = 1;	
	  for (WebElement headerRow : obj.header ) {
		  
		  
		  String HeaderRow = headerRow.getAttribute("textContent");
		  
		 
		 System.out.print(HeaderRow+" ");
		  String Name = "name"+i;
		  
		  Utility.setCellData("Sheet1", Name , 1, HeaderRow)  ;
		  System.out.println(Name);
		  i++;
	  }
	 
	  int j = 2;
		  for (WebElement printerList : obj.printerList ) {
			  
			  
			  String PrinterList = printerList.getAttribute("textContent");
			  
			  Utility.setCellData("Sheet1", "Printers" ,j , PrinterList)  ;
			  System.out.println(PrinterList);  
			  j++;
		  
	  }
	  int z=2;
		  for (WebElement tonerList : obj.tonerList ) {
			  
			  
			  String TonerList = tonerList.getAttribute("textContent");
			  Utility.setCellData("Sheet1", "Toner & Cartridges" ,z , TonerList);
			 
			  System.out.println(TonerList);  
			  z++;
		  
	  }
	  
		  obj.hpButton.click();
		  
		  
	  }
	
  }
  
  

